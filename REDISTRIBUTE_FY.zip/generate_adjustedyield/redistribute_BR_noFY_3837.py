import os
import math
import sys
input=sys.argv[1]
f=open(input,'r')
line=f.readline()
line=line.split()
list_decay=line[0]
op_lib=line[1]
full_lib=line[2]
decay_index=line[3]
redis_list=line[4]
decay_BR=line[5]
f.close() 
cons=math.log(2)
## load full transition  ##
f=open(list_decay,'r')
lines=f.readlines()
f.close()
ll= len(lines)
mom=[]
dau=[]
BR=[]
for i in range (ll):
    tmp=lines[i].split()
    mom.append(int(tmp[0]))
    dau.append(int(tmp[1]))
    BR.append(float(tmp[2]))
    #print(mom[i],dau[i],BR[i])
##load selected list
#### test let take full list
f=open(op_lib,'r')
lines=f.readlines()
f.close()
ID5_selected=[]
for i in range (1,len(lines)):
    tmp=lines[i].split()
    iso5=int(tmp[1])
    ID5_selected.append(iso5)



##load full list
f=open(full_lib,'r')
lines=f.readlines()
f.close()
ll=len(lines)
ID5_full=[]
for i in range (1,ll):
    tmp=lines[i].split()
    ID5=int(tmp[1])
    ID5_full.append(ID5)
##load removed list
ID5_removed=[]
for i in range (len(ID5_full)):
    if ID5_full[i] in ID5_selected:
        continue
    else:
        ID5_removed.append(ID5_full[i])
## start re-evaluate BR decay only 
num_rm=len(ID5_removed)
num_sel=len(ID5_selected)
BR_tmp_rm=[]
BR_selected=[]
dau_tmp_rm=[]
mom_removed=[]
mom_selected=[]
dau_selected=[]
## finding the mother
for i in range(num_rm):
    if ID5_removed[i] in mom:
        for j in range(len(mom)):
            if mom[j]==ID5_removed[i]:
                #print(mom[j],dau[j],BR[j])
                dau_tmp_rm.append(dau[j])
                BR_tmp_rm.append(BR[j])
                mom_removed.append(mom[j])
#w=open('adjust_BR_mom_dau','w')
print('!!!!!')
kk=0
## using new algorithm !! Recursion
## pre-treatment for recursion
num_mom=len(mom)
tmp_list=[]
### sorting
for i in range (num_mom):
	tmp_list.append((mom[i],dau[i],BR[i]))
def take_dau(elem):
    return elem[1]
def take_mom(elem):
    return elem[0]
tmp_list.sort(key=take_dau)
tmp_list.sort(key=take_mom)

###reset
mom=[]
dau=[]
BR=[]
for i in range(num_mom):
	mom.append(tmp_list[i][0])
	dau.append(tmp_list[i][1])
	BR.append(tmp_list[i][2])
#        print(mom[i],dau[i],BR[i])
#stop
##### RUN RECURSION
def recursion_elem(s_index,mom_ind, acc_br):
	"""
	Input:
		s_index: a set of indexs of subsect of mom, distinct elements 
		acc_br: 

		A
	Returns:
		a set of 
	"""
	print("############ BEGIN OF RECURSION ###############")

	assert len(s_index) == len(acc_br)
	#print("s_index=",s_index)
	# find tau(s)
	if len(mom_ind)==0:
		return 405
	corresponding_dau = [] 
	corresponding_BR =[]
	for m_id in s_index: # e.g., s_index= (0, 4)
		corresponding_dau.append(dau[m_id]) # dau = [2004, 200]
		corresponding_BR.append(BR[m_id]) # e.g., (0.3, 0.1)
	#############################
	# PART 1
	#############################
	# daus(s) intersects sel 

	dau_in_sel_ind = [i for i in s_index if dau[i] in ID5_selected] # len(dau_in_sel_ind) = l1
        print( len(dau_in_sel_ind))
         #   print(mom[mom_ind[1]])
         #   stop
    
	
	dau_in_sel_ind_wrt_s_index = [j for (j,i) in enumerate(s_index) if dau[i] in ID5_selected] # len(dau_in_sel_ind) = l1
	#print("Check dau_in_wrt_to s_idex",dau_in_sel_ind_wrt_s_index)
	# dau_in_sel_ind: relative to mom 
	
	current_br_part1 = [corresponding_BR[i] for i in dau_in_sel_ind_wrt_s_index]
	#print("current_br_part1 = ",current_br_part1)
	#print("acc_br= ",acc_br)
	# print(len(acc_br))
	# update br
	new_br_part1_t = [acc_br[i] for i in dau_in_sel_ind_wrt_s_index]
	new_br_part1 = [] 
	# ASSERTION: len(acc_br) = l1
	# khang check 
	for a,b in zip(new_br_part1_t, current_br_part1):
		new_br_part1.append(a * b)

	#print("(mom,Dau, br) in sel:", [mom[mom_ind[0]] ], [dau[i] for i in dau_in_sel_ind ], [new_br_part1 [i] for i in range (len(dau_in_sel_ind))])
	for i in range (len(dau_in_sel_ind)):
		print(mom[mom_ind[0]],mom[dau_in_sel_ind[i]],dau[dau_in_sel_ind[i]],new_br_part1[i])
		mom_selected.append(mom[mom_ind[0]])
		dau_selected.append(dau[dau_in_sel_ind[i]])
		BR_selected.append(new_br_part1[i])
	# dau(s) / sel 
        subs = [i for i in corresponding_dau if i not in ID5_selected]
        subs_idx=[]
        for i in range (len(corresponding_dau)):
        	for j in range(len(subs)):
        		if subs[j]==corresponding_dau[i]:
        			subs_idx.append(i)
        # print("check id in subs",subs_idx)
    ########################
    # PART 3
    ########################
	# subs not in mom 
	subs_not_in_mom = [i for i in subs if i not in mom] # len(subs_not_in_mom) = l3
	#print("Dau in sel not in mom", subs_not_in_mom)
	if len(subs_not_in_mom)!=0:
		#print("Warning not in ID5_selected and not in mom")
		return 
    ############################
    # PART 2 
    ############################    
    # subs intersects mom 

    
    # print("SUBBBBBB=", subs)
	rec_o = [i for i in subs if i in mom]
	rec_o_ind = convert_elem_to_index(rec_o) # len(rec_o_ind) = l2
	# print("!!!!!!",rec_o)
	subs_idx_p2=[]
	for ii in range (len(rec_o)):
		for jj in range (len(dau)):
			if mom[jj] == rec_o[ii]:
				subs_idx_p2.append(subs_idx[ii])
	#print("path",subs_idx_p2)
	# for i in range (len(rec_o)):
	# 	for j in range (len(subs)):
	# 		if rec_o[i]==subs[j]:
	# 			subs_idx_p2.append(subs_idx[j])
				
	# print("sub_indices Part2 ",subs_idx_p2)
	cr_br_part2 = [corresponding_BR[i] for i in subs_idx_p2] # len(subs_idx_p2) = len(rec_o_ind)
	# print("FGFGFGFF", acc_br,subs_idx_p2 )

	new_br_part2_t = [acc_br[i] for i in subs_idx_p2]
	new_br_part2 = []
	for (a,b) in zip(cr_br_part2,new_br_part2_t ):
		new_br_part2.append(a*b)
	rec_o_ind = convert_elem_to_index(rec_o) # len(rec_o_ind) = l2
	if len(rec_o_ind) == 0:
		return 
	else:
		# print("NEW S", rec_o_ind )
		return recursion_elem(rec_o_ind,mom_ind, new_br_part2) 


def convert_elem_to_index(elems):
	out = []
	for i in range(len(mom)):
		if mom[i] in elems:
			out.append(i)
	return out 
##### end of new algorithm 

for ii in range (len(ID5_selected)):
	tmp=[]
	tmp_br=[]
	if ID5_selected[ii] in mom:
		for kk in range (len(mom)):
			if mom[kk]==ID5_selected[ii]:
				tmp.append(kk)
				tmp_br.append(1)
        if (len(tmp))>0:
            print(recursion_elem(tmp,tmp,tmp_br))
#stop
#stop
## test 

print(len(mom),len(mom_removed),len(mom_selected),len(dau_selected))
for i in range (len(mom_selected)):
    print(mom_selected[i], dau_selected[i],'%12.5e'%BR_selected[i])
#w.close()
# re arrange
dau_sel_arrange=[]
for i in range (len(mom_selected)):
    if dau_selected[i] in dau_sel_arrange:
        continue
    else:
        dau_sel_arrange.append(dau_selected[i])
print(len(dau_sel_arrange))
dau_sel_arrange.sort()
print(len(dau_sel_arrange))
print(len(ID5_selected))
#stop
## insert value to a new matrix, no fission yield 
burn_matrix_decay=[]
MAT_loc=[]
for i in range(len(ID5_selected)):
    burn_matrix_decay.append([])
    MAT_loc.append([])
    for j in range (len(ID5_selected)):
        burn_matrix_decay[i].append(0.0)
        MAT_loc[i].append(0.0)
## load location 
f=open(decay_index,'r')
lines=f.readlines()
f.close()
ll=len(lines)
print(ll,len(ID5_selected),len(mom_selected))
for i in range (ll):
    tmp=lines[i].split()
    #print(len(tmp))
    for j in range (len(tmp)):
        MAT_loc[i][j]=int(tmp[j])
#stop
# reset the remove term, it will be calculated in STREAM
#for i in range (len(ID5_selected)):
#    print(MAT_loc[i][i])
#stop

###rearange the list 
len_tmp=len(mom_selected)
tmp_list=[]
for i in range (len_tmp):
    tmp_list.append((mom_selected[i],dau_selected[i],BR_selected[i]))

tmp_list.sort(key=take_dau)
tmp_list.sort(key=take_mom)

## reset 
mom_selected=[]
dau_selected=[]
BR_selected=[]
for i in range(len_tmp):
    mom_selected.append(tmp_list[i][0])
    dau_selected.append(tmp_list[i][1])
    BR_selected.append(tmp_list[i][2])

## done re-arrange
print(len(mom_selected))

print('calculate the sum BR')
w=open(redis_list,'w')
### calculate the sum BR :
#w.write('%d'%mom_selected[0]+' '+'%d'%dau_selected[0]+' '+'%12.7e'%BR_selected[0]+'\n')
for j in range (1,len(dau_selected)):
    if mom_selected[j]==mom_selected[j-1]:
        if dau_selected[j]==dau_selected[j-1]:
      #      print('what')
            #stop
            BR_selected[j]=BR_selected[j]+BR_selected[j-1]
    #print(mom_selected[j],dau_selected[j],'%12.5e'%BR_selected[j])
    #w.write('%d'%mom_selected[j]+' '+'%d'%dau_selected[j]+' '+'%12.5e'%BR_selected[j]+'\n')
#w.close()
#### this past is for removing duplicate pairs
### mom_selected, dau_selected, BR_selected
m=mom_selected
d=dau_selected
br=BR_selected
w_d=[]
w_m=[]
w_br=[]
bla=len(mom_selected)
for t in range (1,bla):
    if m[t]==m[t-1] and d[t]==d[t-1]:
        del (m[t-1])
        del (d[t-1])
        del (br[t-1])
        m.insert(t-1,0)
        d.insert(t-1,0)
        br.insert(t-1,0)
for i in range (bla):
	if m[i]!=0:
		w_m.append(m[i])
		w_d.append(d[i])
		w_br.append(br[i])
for j in range (len(w_m)):
	w.write('%d'%w_m[j]+' '+'%d'%w_d[j]+' '+'%12.5e'%w_br[j]+'\n')
w.close()
#### ending for writing the redistributed mom_dau_list
#stop
### set the BR 
for t in range (len(dau_sel_arrange)):
    for i in range (len(mom_selected)):
        if dau_selected[i] == dau_sel_arrange[t]:
            #print(mom_selected[i],dau_selected[i],BR_selected[i])
            for x in range (len(ID5_selected)):
                if MAT_loc[x][x]==dau_selected[i]:
                    #print(MAT_loc[x][x])
                    #print('dau')
                    for y in range (len(ID5_selected)):
                        if x!=y and MAT_loc[x][y]==mom_selected[i]:
                            #print(MAT_loc[x][y])
                            burn_matrix_decay[x][y]=BR_selected[i]
                            print (MAT_loc[x][y],dau_selected[i],BR_selected[i])

                    #for y in range (len(ID5_selected)):
                    #    print(MAT_loc[x][y])

w=open(decay_BR,'w')
for i in range (len(ID5_selected)):
    for j in range (len(ID5_selected)):
         w.write('%12.5e'%burn_matrix_decay[i][j]+'  ')
    w.write('\n')
w.close()
