import os
import sys
input= sys.argv[1]
f=open(input,'r')
line=f.readline()
line=line.split()
decay_index=line[0]
full_index=line[1]
reaction_index=line[2]
f.close()

f=open(decay_index,'r')
lines=f.readlines()
f.close()
num=len(lines)
decay_mat=[]
rec_mat=[]
for i in range (num):
    decay_mat.append([])
    rec_mat.append([])
    for j in range (num):
        decay_mat[i].append(0.0)
        rec_mat[i].append(0.0)
for i in range (num):
    tmp=lines[i].split()
    for j in range (len(tmp)):
        decay_mat[i][j]=int(tmp[j])

f=open(full_index,'r')
lines=f.readlines()
f.close()

for i in range (num):
    tmp=lines[i].split()
    for j in range (len(tmp)):
        rec_mat[i][j]=int(tmp[j])

for i in range (num):
    for j in range (num):
        if rec_mat[i][j]==decay_mat[i][j] and i!=j:
            rec_mat[i][j]=0


w=open(reaction_index,'w')
for i in range (num):
    for j in range(num):
        w.write('%12d'%rec_mat[i][j])
    w.write('\n')
w.close()






