import math
f=open('mom_dau_BR_redistributed_3837','r')
lines=f.readlines()
f.close()
m=[]
d=[]
br=[]
for i in range(len(lines)):
    tmp=lines[i].split()
    m.append(int(tmp[0]))
    d.append(int(tmp[1]))
    br.append(float(tmp[2]))
tt=len(m)
print(tt)
rm_m=[]
rm_d=[]
rm_br=[]
rm_id=[]
for t in range (1,tt):
    if m[t]==m[t-1] and d[t]==d[t-1]:
        del (m[t-1])
        del (d[t-1])
        del (br[t-1])
        m.insert(t-1,0)
        d.insert(t-1,0)
        br.insert(t-1,0)
for i in range (tt):
    if m[i]!=0:
        rm_m.append(m[i])
        rm_d.append(d[i])
        rm_br.append(br[i])


#
print("final result")
for ii in range (len(rm_m)):
    print(rm_m[ii],rm_d[ii],rm_br[ii])
