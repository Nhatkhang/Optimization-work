input: reduced_decay_lib (some additional nuclide must be manually added to this list); Matrix of full transition (no FY); Matrix of decay transition (no FY).
output: path matrix for decay and reaction, deacay BR and the adjust FY lib
Run: generate
output:
FY_check_3837
matrix_decay_BR_3837
matrix_reaction_index_3837
matrix_decay_index_3837
mom_dau_BR_noFY_3837