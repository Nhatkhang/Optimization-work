import sys
#input=sys.argv[1]
#output=sys.argv[2]
#print("input",input)
#print("output",output)
a=[1,1,4,2,2,4]
b=[2,2,3,5,5,2]
c=[0.2,1,0.4,0.5,0.6,0.5]
print(a)
print(b)
print(c)
for t in range(1,len(b)):
    if (b[t]==b[t-1]) and (a[t]==a[t-1]):# and (c[t]>c[t-1]):
        del (b[t-1])
        del(a[t-1])
        del(c[t-1])
        a.append(0)
        b.append(0)
        c.append(0)
        #print(a[t],b[t],c[t])
    #else:
    #    print(a[t],b[t],c[t])
test_a=[]
test_b=[]
test_c=[]
#test_a.append(a[0])
#test_b.append(b[0])
#test_c.append(c[0])
for i in range (len(b)):
    if  (a[i]!=0):
        test_a.append(a[i])
        test_b.append(b[i])
        test_c.append(c[i])
print(a)
print(b)
print(c)
print("final answer")
print(test_a)
print(test_b)
print(test_c)
