import os
import math
import sys
#### create a file that contain input and out put information 
#### input_mom_dau_list1
input= sys.argv[1]
f=open(input,'r')
line=f.readline()
line=line.split()
full_lib=line[0]
matrix=line[1]
list=line[2]
f.close()
print(matrix)
print(list)
f=open(full_lib,'r')
## this is for full size 3837 burn up matrix
lines=f.readlines()
f.close()
temp=len(lines)
ID5=[]
ID6=[]
HL=[]
lamda=[]
BR=[]
num_id=temp-1
for i in range (1,temp):
    tmp=lines[i].split()
    ID6.append(int(tmp[0]))
    ID5.append(int(tmp[1]))
    HL.append(float(tmp[4]))
print(len(ID6),len(ID5),len(HL))
tmp=math.log(2)
for i in range(len(HL)):
    if HL[i]<1e-100:
        HL[i]=1.0e+32 #set max HL 
    lamda.append(float(tmp)/HL[i])
print(len(lamda))

## set ID and lamda
w=open(list,'w')
f=open(matrix,'r')
lines=f.readlines()
f.close()
n=0
id=[]
num_mom=[]
mom=[]
dau=[]
ll=len(lines)
for i in range (ll):
    m=0
    tmp=lines[i].split()
    tt=len(tmp)
    #print(i)
    #print(tt)
    #f i==3:
        #print(num_mom)
    #    stop
    for  j in range (tt):
        if float(tmp [j]) != 0.00000e+00:
            n=n+1
            if j!=i:
                m=m+1
                mom.append(ID5[j])
                dau.append(ID5[i])
                br=float(tmp[j])
                BR.append(br)
                #print(ID5 [j],ID5[i],br)
                w.write('%d'%ID5 [j]+' '+'%d'%ID5 [i]+' '+'%12.5e'%br+'\n')
                print(ID5 [j],ID5[i])
    num_mom.append(m)
print(n)
print(tt,ll)
print(len(mom))
print(len(dau))
#stop
#print(num_mom)
real_dau=[]
real_mom=[]
for i in range (len(dau)):
    if dau[i] in real_dau:
        continue
    else:
        real_dau.append(dau[i])
print(len(real_dau))
### having the list of daugter of nuclides






















