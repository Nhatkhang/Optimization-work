import os
import collections
import sys
input=sys.argv[1]
f=open(input,'r')
line=f.readline()
line=line.split()
out_FY=line[0]
full_FY=line[1]
decay_list=line[2]
full_lib=line[3]
op_lib=line[4]
redis_list=line[5]
f.close()






w=open(out_FY,'w')
f=open(full_FY,'r')
lines=f.readlines()
f.close()
w.write(lines[0])
w.write(lines[1])
w.write(lines[2])
w.write(lines[3])
w.write(lines[4])
ll=len(lines)
num_FP=ll-5
num_fertile=int(lines[0].split()[0])
gr=int(lines[4].split()[0])
col=gr*num_fertile
print(col)
print(gr)
print(num_fertile)
print(num_FP,ll)
ID5_FY=[]
ID6_FY=[]
FYi=[]
for i in range (num_FP):
    FYi.append([])
    for j in range (col):
        FYi[i].append(0.0)
print (ll-5)
index=0
for i in range (5,ll):
    tmp=lines[i].split()
    tmp_len=len(tmp)
    iso6=int(tmp[0])
    ID6_FY.append(iso6)
    z=int(iso6/10000)
    m=iso6%10
    a=int(iso6/10)%1000
    if m==1:
        iso5=z*1000+a+400
    elif m==2:
        iso5=z*1000+a+500
    elif m==3:
        iso5=z*1000+a+600
    else:
        iso5=z*1000+a
    ID5_FY.append(iso5)
    col=0
    for j in range (1,tmp_len):
        fy=float(tmp[j])
        FYi[index][col]=fy
        #print(fy)
        col=col+1
    index=index+1
print(index,col,num_FP)
print("id5")
def take_mom(elem):
    return elem[0]
#### recreating the accumulative Yield
#ID6_acc=ID6_FY
#ID5_acc=ID5_FY
### set the accumulative yield is equal to the independent yield first
FYc=[]
for i in range (num_FP):
    FYc.append([])
    for j in range (col):
        FYc[i].append(0.0)
for i in range (len(ID5_FY)):
    FYc[i][:]=FYi[i][:]
## this is for full 3837 nuclides
f=open(decay_list,'r')
lines=f.readlines()
mom=[]
dau=[]
BR=[]
for i in range (len(lines)):
    tmp=lines[i].split()
    mom.append(int(tmp[0]))
    dau.append(int(tmp[1]))
    BR.append(float(tmp[2]))

# open file that contain index and decay fraction (modified by hand outside)
#f=open('mom_dau_indx_br','r')
#lines=f.readlines()
#f.close()
#ll= len(lines)
#mom_idx=[]
#dau_idx=[]
#BR_tmp=[]
#for i in range (ll):
#    tmp=lines[i].split()
#    mom_idx.append(int(tmp[0]))
#    dau_idx.append(int(tmp[1]))
#    BR_tmp.append(float(tmp[2]))
#print(len(BR_tmp),len(mom_idx),len(dau_idx))
# sorting key=mom

num_mom=len(mom)
#tmp_list=[]
#for i in range (num_mom):
#    tmp_list.append((mom[i],dau[i],BR[i]))
#tmp_list.sort(key=take_mom)
### reset
#mom=[]
#dau=[]
#BR=[]
#print("mom_dau_BR list")
#for i in range (num_mom):
#    mom.append(tmp_list[i][0])
#    dau.append(tmp_list[i][1])
#    BR.append(tmp_list[i][2])
#    #print(mom[i],dau[i],BR[i])
#
## check the mom _dau_list
#### create the indices for mom and dau, BR
#
#### testing 
#
#for i in range (num_mom):
#    if dau[i] in ID5_FY:
#        if mom[i] not in ID5_FY:
#            print(mom[i],dau[i],BR[i])
##stop
mom_idx=[]
#mom_tmp=[]
dau_idx=[]
dau_tmp=[]
BR_tmp=[]
#count=0
print("CREATE the FYC")
for i in range (num_mom):
    if dau[i] in ID5_FY and mom[i] in ID5_FY:
        BR_tmp.append(BR[i])
        for tt in range (len(ID5_FY)):
            if ID5_FY[tt]==dau[i]:
                dau_idx.append(tt)
            if ID5_FY[tt]==mom[i]:
                mom_idx.append(tt)
#                mom_tmp.append(mom[i])
##sorting 
##for i in range (num_mom):
##    if dau[i]  in ID5_FY:
##        if mom[i] in ID5_FY:
##            mom_tmp.append(mom[i])
##            dau_tmp.append(dau[i])
print(len(dau_idx),len(mom_idx),len(BR_tmp))
#for tt in range (len(dau_idx)):
#    print(mom_idx[tt],dau_idx[tt],BR_tmp[tt])
#
#
#
#
def take_dau(elem):
    return elem[1]
num_check=len(mom_idx)
tmp_list=[]
for i in range (num_check):
    tmp_list.append((mom_idx[i],dau_idx[i],BR_tmp[i]))
tmp_list.sort(key=take_mom)
## reset
mom_idx=[]
dau_idx=[]
BR_tmp=[]
#dau_idx.append(1)
for i in range(num_check):
    mom_idx.append(tmp_list[i][0])
    dau_idx.append(tmp_list[i][1])
    BR_tmp.append(tmp_list[i][2])
    #print(mom_idx[i],dau_idx[i])
##### rearrange 
for k in range (100):
    for i in range (len(mom_idx)):
        if dau_idx[i] in mom_idx:
            id=i
            for ii in range (len(mom_idx)):
                if mom_idx[ii]==dau_idx[i]:
                    im=ii
                    if id>im:
                        m1=mom_idx[id]
                        d1=dau_idx[id]
                        br1=BR_tmp[id]
                        mom_idx.insert(im,m1)
                        dau_idx.insert(im,d1)
                        BR_tmp.insert(im,br1)
                        del(mom_idx[id+1])
                        del(dau_idx[id+1])
                        del(BR_tmp[id+1])

#check_dau=[]
##tmp=dau_idx
##tmp.sort()
#from itertools import groupby
#check_num=[len(list(group)) for key, group in groupby(dau_idx)]
#for i in range (len(mom_idx)):
#    if dau_idx[i] in check_dau:
#        continue
#    else:
#        check_dau.append(dau_idx[i])
#print(len(check_num),len(check_dau))
#for i in range (len(check_dau)):
#    print(ID5_FY[check_dau[i]],check_num[i])
##stop
#
##stop
### TODO: calculate the yield as in the order of mom, but the daughter also need to be in order !!!!!
print("TEST")

### find the mom that are not included in the FPs first, it can be caluculated easily by
### FYc(X)=FYi(X)+BR(C->X)*FYi(C) where C-->X

#for i in range (len(mom_idx)):
#    for ii  in range (len(ID5_FY)):
#        if ii==mom_idx[i]:
#            #print(ID5_FY[dau_idx[ii+1]],ID5_FY[mom_idx[ii]],mom_idx[ii],dau_idx[ii+1],BR_tmp[ii])
#            for tt in range (col):
#                FYc[dau_idx[ii+1]][tt]=FYc[dau_idx[ii+1]][tt]+BR_tmp[ii]*FYc[mom_idx[ii]][tt]
#                print(ID5_FY[mom_idx[ii]],ID5_FY[dau_idx[ii+1]],mom_idx[ii],dau_idx[ii+1],FYc[dau_idx[ii+1]][tt],FYc[mom_idx[ii]][tt])
#

for i in range (len(mom_idx)):
    print(mom_idx[i],dau_idx[i],BR_tmp[i])



#stop
#for i in range (len(ID5_FY)):
#    for ii in range (len(mom_idx)):
#        if mom_idx[ii]==i:
#            if mom_idx[ii] in dau_idx:
#                for tt in range (len(dau_idx)):
#                    if dau_idx[tt]==mom_idx[ii]:
#                        print (ID5_FY[mom_idx[ii]],ID5_FY[dau_idx[ii]],ID5_FY[mom_idx[tt]],ID5_FY[dau_idx[tt]],ii,tt)
#def recursionpair(a,b)
#""" This is recusion 
#    Input is the pair of mom_idx and dau_idx
#"""
#mom_idx_in_ID5=[i for i in range (len(ID5_FY)) if i in mom_idx]
#cor_ddau_idx=[]
#for i in range (len(
#for tt in range (len(mom_idx_in_ID5)):
#    print(mom_idx_in_ID5[tt])
### The accumulative yield needs to be calculated in the order of mother, but the daughter FYc also needs to  be calculated completely
print("check")
for ii in range (len(mom_idx)):
            for tt in range (col):
                FYc[dau_idx[ii]][tt]=FYc[dau_idx[ii]][tt]+BR_tmp[ii]*FYc[mom_idx[ii]][tt]
                print(mom_idx[ii],dau_idx[ii])
#stop

#stop
#num_check=len(ID5_FY)
#tmp_list=[]
#for i in range (num_check):
#    tmp_list.append((ID5_FY[i],FYc[i][0],FYc[i][1],FYc[i][2],FYc[i][3],FYc[i][4],FYc[i][5],FYc[i][6],FYc[i][7] \
#	,FYc[i][8],FYc[i][9],FYc[i][10],FYc[i][11],FYc[i][12],FYc[i][13],FYc[i][14],FYc[i][15],FYc[i][16],FYc[i][17] \
#	,FYc[i][18],FYc[i][19],FYc[i][20],FYc[i][21],FYc[i][22],FYc[i][23],FYc[i][24],FYc[i][25],FYc[i][26],FYc[i][27] \
#	,FYc[i][28],FYc[i][29],FYc[i][30],FYc[i][31],FYc[i][32],FYc[i][33],FYc[i][34],FYc[i][35],FYc[i][36],FYc[i][37] \
#	,FYc[i][38],FYc[i][39],FYc[i][40],FYc[i][41],FYc[i][42],FYc[i][43],FYc[i][44],FYc[i][45],FYc[i][46],FYc[i][47] \
#	,FYc[i][48],FYc[i][49],FYc[i][50],FYc[i][51],FYc[i][52],FYc[i][53],FYc[i][54],FYc[i][55],FYc[i][56],FYc[i][57] \
#	,FYc[i][58],FYc[i][59],FYc[i][60],FYc[i][61],FYc[i][62],FYc[i][63],FYc[i][64],FYc[i][65],FYc[i][66],FYc[i][67] \
#	,FYc[i][68],FYc[i][69],FYc[i][70],FYc[i][71],FYc[i][72],FYc[i][73],FYc[i][74],FYc[i][75],FYc[i][76],FYc[i][77] \
#	,FYc[i][78],FYc[i][79],FYc[i][80],FYc[i][81],FYc[i][82],FYc[i][83],FYc[i][84],FYc[i][85],FYc[i][86],FYc[i][87] \
#	,FYc[i][88],FYc[i][89],FYc[i][90],FYc[i][91],FYc[i][92] ))
#	
##tmp_list.sort(key=take_mom)
### reset
#FYc=[]
#ID5_FY=[]
#for i in range (num_check):
#    FYc.append([])
#    for ii in range (col):
#        FYc[i].append(0.0)
#for i in range (num_check):
#    ID5_FY.append(tmp_list[i][0])
#    for tt in range (col):
#        FYc[i][tt]=tmp_list[i][tt+1]
       



#for i in range (len(mom)):
#    if dau[i] in ID5_FY and mom[i] in ID5_FY:
#        for ii in range (len(ID5_FY)):
#            if ID5_FY[ii]==dau[i]:
#                for t in range (len(ID5_FY)):
#                    if ID5_FY[t]==mom[i]:
#                        for tt in range (col):
#                            FYc[ii][tt]=FYc[ii][tt]+BR[i]*FYc[t][tt]
#                            #print(mom[i],dau[i],FYc[ii][tt],FYc[t][tt])
#                            print(mom[i],ID5_FY[t],dau[i],ID5_FY[ii],BR[i],FYc[ii][tt],FYc[t][tt])
#
#stop



print("Checking the FYc")

#stop
# check
#for i in range (len(ID5_FY)):
   #for cc in range (col):
#    print(ID5_FY[i],FYc[i][0])
#stop








#f=open('accumulativeYEILD_r01.lib','r')
#lines=f.readlines()
#f.close()
#ll=len(lines)
#num_FP=ll-5
#num_fertile=int(lines[0].split()[0])
#gr=int(lines[4].split()[0])
#col=gr*num_fertile
#print(col)
#print(gr)
#print(num_fertile)
#print(num_FP,ll)
#FYc=[]
#for i in range (num_FP):
#    FYc.append([])
#    for j in range (col):
#        FYc[i].append(0.0)
#index=0
#for i in range (5,ll):
#    tmp=lines[i].split()
#    tmp_len=len(tmp)
#    col=0
#    for j in range (1,tmp_len):
#        fy=float(tmp[j])
#        FYc[index][col]=fy
#        col=col+1
#    index=index+1
#print(index)
#print(col)
## pre-treatment is done
#### load the full list of the nuclide
f=open(full_lib,'r')
lines=f.readlines()
f.close()
ll=len(lines)
n_r=ll-1
print(n_r)
ID5_full=[]
for i in range (1,ll):
    tmp=lines[i].split()
    ID5=int(tmp[1])
    ID5_full.append(ID5)
print(len(ID5_full))
### load selected list
f=open(op_lib,'r')
lines=f.readlines()
f.close()
ID5_selected=[]
for i in range (1,len(lines)):
    tmp=lines[i].split()
    iso5=int(tmp[1])
    ID5_selected.append(iso5)
#check the selected nuclides
print(len(ID5_selected))
#stop
# check the selected nuclides for FY 
ID5_FY_sel=[]
ID6_FY_sel=[]
for i in range(num_FP):
    if ID5_FY[i] in ID5_selected:
        for j in range (len(ID5_selected)):
            if ID5_selected[j]==ID5_FY[i]:
                ID5_FY_sel.append(ID5_selected[j])
                ID6_FY_sel.append(ID6_FY[i])
                #print(ID5_selected[j])
print (len(ID5_FY_sel),num_FP)
#stop
#print("nuclide that has yield but not in the decay lib")
#hmm=open('missing_nu_FY','w')
#for ii in range (num_FP):
#    if ID5_FY[ii] not in ID5_selected :
#        hmm.write('%d'%ID6_FY[ii])
#        for j in range (col):
#            hmm.write('%12.5e'%FYi[ii][j])
#        hmm.write('\n')
#hmm.close()
        #print(ID5_FY[ii])
#print("this is because of 1640 reduction ")
#stop
FYi_sel=[]
FY_untouch=[]
for i in range (len(ID5_FY_sel)):
    FYi_sel.append([])
    FY_untouch.append([])
    for j in range (col):
        FYi_sel[i].append(0.0)
        FY_untouch[i].append(0.0)
##test
#ID5_FY_sel.sort()
for i in range (num_FP):
    if ID5_FY[i] in ID5_FY_sel:
        for m in range (len(ID5_FY_sel)):
            if ID5_FY_sel[m]==ID5_FY[i]:
                FYi_sel[m][:]=FYc[i][:]
                FY_untouch[m][:]=FYc[i][:]
                #print(ID5_FY[i])
#check the FY_sel is correct

#Assume the FYi==FYc for all selected FP at first, then will be reduced later 

print(len(ID5_selected),len(ID5_full))
print('load indepenent FY, accumulative FY, selected and removed nuclides DONE!!!') 
## load mom_daughter-br that has been re adjusted 
### check 
#stop
f=open(redis_list,'r')
#test
#f=open('mom_dau_BR_sum_adjust','r')

lines=f.readlines()
f.close()
ll= len(lines)
mom=[]
dau=[]
BR=[]
for i in range (ll):
    tmp=lines[i].split()
    mom.append(int(tmp[0]))
    dau.append(int(tmp[1]))
    BR.append(float(tmp[2]))
print(len(BR),len(mom),len(dau))
num_mom=len(mom)
print('load mother-daughter-branch_ratio DONE!!!')
for i in range (len(mom)):
    print(mom[i],dau[i],BR[i])
#stop
## counting how many mother that create the daughter
##start re-evaluate FY
print('start re-evaluate FY')
#num_FY_sel=len(ID5_FY_sel)
#print(num_FY_sel)
##stop
##print(num_rm)
#
### find the pair of mom and the FPs-daughter
### FYi(C)==FYc(C)-FYc(A)*BR(A->C)
#count=0
#count1=0
#dau_sel=[]
##mom_sel=[]
##BR_sel=[]
#for i in range (num_mom):
#    if dau[i] in ID5_FY_sel :
#        count=count+1
#        dau_sel.append(dau[i])
#        #mom_sel.append(mom[i])
#        #BR_sel.append(BR[i])
#        print(mom[i],dau[i],BR[i])
#rint(count,count1,len(ID5_FY_sel))
### Khang test
#for i in range (count):
#    FYi_sel.append([])
#    FY_untouch.append([])
#    for j in range (col):
#        FYi_sel[i].append(0.0)
#        FY_untouch[i].append(0.0)
#for tt in range (count):
#    for ii in range (len(ID5_FY)):
#        if ID5_FY[ii]==dau_sel[tt]:
#            FYi_sel[tt][:]=FYc[ii][:]
#print(len(FYi_sel))
#stop
##stop
###TODO: find all mom_FPs_BR(mom-FPs) done
###TODO: adjust the yield
indx_FPS=[]
indx_mom_FPS=[]
BR_FPS=[]
##### khang test
##print(len( BR_FPS),len(indx_FPS),len(indx_mom_FPS))
#### let the ID5_FY_sel==dau_sel
for i in range (num_mom):
    if dau[i] in ID5_FY_sel and mom[i] in ID5_FY_sel:
        print(mom[i],dau[i],BR[i])
        BR_FPS.append(BR[i])
        for ii in range (len(ID5_FY_sel)):
            if ID5_FY_sel[ii] == dau[i]:
                a=1
                indx_FPS.append(ii)
                #print("dau of FPS index",ii)
            if ID5_FY_sel[ii] == mom[i]:
                c=1
                indx_mom_FPS.append(ii)
                #print("mom of FPS index",ii)
print("index test")
#for i in range (len(BR_FPS)):
#    print(indx_mom_FPS[i],indx_FPS[i],BR_FPS[i])
#print(len(dau_sel),len(indx_FPS),len(BR_FPS))
#stop

### sort the indx_FPS to determine how many mom that create that FPS
#tmp_list=[]
#num=len(indx_mom_FPS)
#for ii in range (num):
#    tmp_list.append((indx_mom_FPS[ii],indx_FPS[ii],BR_FPS[ii]))
###reset
#indx_FPS=[]
#indx_mom_FPS=[]
#BR_FPS=[]
#tmp_list.sort(key=take_dau)
#for tt in range (num):
#    indx_mom_FPS.append(tmp_list[tt][0])
#    indx_FPS.append(tmp_list[tt][1])
#    BR_FPS.append(tmp_list[tt][2])
#print('sort')
#for tt in range(num):
#    print(indx_mom_FPS[tt],indx_FPS[tt],BR_FPS[tt])
##stop



#f=open('mom_dau_br_optimize','r')
#lines=f.readlines()
#f.close()
#for i in range (len(lines)):
#    tmp=lines[i].split()
#    indx_mom_FPS.append(int(tmp[0]))
#    indx_FPS.append(int(tmp[1]))
#    BR_FPS.append(float(tmp[2]))
###find the FYc for the mom
FYc_mom=[]
for i in range (len(ID5_FY_sel)):
#for i in range (count):
    FYc_mom.append([])
    for ii in range (col):
        FYc_mom[i].append(0.0)
for tt in range (len(ID5_FY_sel)):
#for tt in range (count):
        FYc_mom[tt][:]=FYi_sel[tt][:]

for ii in range (len(indx_mom_FPS)):
    for tt in range (col):
        print(ID5_FY_sel[indx_mom_FPS[ii]],FYc_mom[indx_mom_FPS[ii]][tt])
#### FYc_mom is correct 
## START adjust
#stop
tmp_list=[]
num=len(indx_mom_FPS)
for ii in range (num):
    tmp_list.append((indx_mom_FPS[ii],indx_FPS[ii],BR_FPS[ii]))
##reset
indx_FPS=[]
indx_mom_FPS=[]
BR_FPS=[]
tmp_list.sort(key=take_mom)
for tt in range (num):
    indx_mom_FPS.append(tmp_list[tt][0])
    indx_FPS.append(tmp_list[tt][1])
    BR_FPS.append(tmp_list[tt][2])
print('sort')
for tt in range(num):
    print(indx_mom_FPS[tt],indx_FPS[tt],BR_FPS[tt])
print("START ADJUST")
for tt in range (len(indx_FPS)):
    for cc in range (col):
        #print(ID5_FY_sel[indx_mom_FPS[tt]],ID5_FY_sel[indx_FPS[tt]],BR_FPS[tt],FYc_mom[tt][cc],FYc_mom[indx_mom_FPS[tt]][cc])
        FYi_sel[indx_FPS[tt]][cc]=FYi_sel[indx_FPS[tt]][cc]-FYc_mom[indx_mom_FPS[tt]][cc]*BR_FPS[tt]
        if FYi_sel[indx_FPS[tt]][cc]<0:
            FYi_sel[indx_FPS[tt]][cc]=0

#stop
#for tt in range (len(ID5_FY_sel)):
#    for ii in range (len(indx_FPS)):
#        if indx_FPS[ii]==tt:
#            for cc in range (col):
#                print(ID5_FY_sel[indx_mom_FPS[ii]],ID5_FY_sel[indx_FPS[ii]],BR_FPS[ii],FYc_mom[tt][cc],FYc_mom[indx_mom_FPS[ii]][cc])
#                FYi_sel[tt][cc]=FYi_sel[indx_FPS[ii]][cc]-FYc_mom[indx_mom_FPS[ii]][cc]*BR_FPS[ii]
#                #if FYi_sel[tt][cc]<0:
                #    FYi_sel[tt][cc]=0

#stop





###let print only dau_sel nuclide
#id=[]
#for ii in range (len(dau_sel)):
#    for tt in range (len(ID5_FY_sel)):
#        if ID5_FY_sel[tt]==dau_sel[ii]:
#            id.append(tt)
#
#print(len(dau_sel),len(id))

Arr=[]
for i in range (len(ID5_FY_sel)):
    Arr.append([])
    for j in range (col+1):
        Arr[i].append(0.0)
print('!!!')
print((len(Arr[1])))
#stop
#print(col)
print(len(FYi_sel[1]))
print(col)
for i in range (len(ID5_FY_sel)):
    Arr[i][0]=int(ID6_FY_sel[i])
    index=0
    for j in range (1,col+1):
        Arr[i][j]=FYi_sel[i][index]
        #print(FYi_sel[i][index])
        index=index+1
        #print(j,index)
for i in range (len(ID5_FY_sel)):
    w.write('%d'%Arr[i][0])
    for j in range (1,col+1):
        w.write('%14.5e'%Arr[i][j])
    w.write('\n')
w.close()



