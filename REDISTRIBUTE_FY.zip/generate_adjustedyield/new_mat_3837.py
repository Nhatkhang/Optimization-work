import os
import sys
input= sys.argv[1]
#mom_dau_BR is decay only
#mom_dau_BR_rx is reaction only
#mom_dau_BR_noFY is both
f=open(input,'r')
line=f.readline()
line=line.split()
list=line[0]
full_lib=line[1]
op_lib=line[2]
index_mat=line[3]

f.close()


f=open(list,'r')
lines=f.readlines()
f.close()
ll= len(lines)
mom=[]
dau=[]
#BR=[]
for i in range (ll):
    tmp=lines[i].split()
    mom.append(int(tmp[0]))
    dau.append(int(tmp[1]))
    #BR.append(float(tmp[2]))
#print(len(BR),len(mom),len(dau))
#print('load mother-daughter-branch_ratio DONE!!!')
### load the full list of the nuclide
f=open(full_lib,'r')
lines=f.readlines()
f.close()
ll=len(lines)
n_r=ll-1
#print(n_r)
ID5_full=[]
for i in range (1,ll):
    tmp=lines[i].split()
    ID5=int(tmp[1])
    ID5_full.append(ID5)
#print(len(ID5_full))
#stop
## load selected nuclide in xs71lib
f=open(op_lib,'r')
lines=f.readlines()
f.close()
ID5_selected=[]
for i in range (1,len(lines)):
    tmp=lines[i].split()
    iso5=int(tmp[1])
    ID5_selected.append(iso5)
#check the selected nuclides
## load the removed nuclide
ID5_removed=[]
for i in range (len(ID5_full)):
    if ID5_full[i] in ID5_selected:
        continue
    else:
        ID5_removed.append(ID5_full[i])
#print(len(ID5_selected),len(ID5_removed),len(ID5_full))
#stop
#print('make a sample chain')
MAT=[]
for i in range (len(ID5_selected)):
    MAT.append([])
    for f in range (len(ID5_selected)):
        MAT[i].append(0.0)
for i in range (len(ID5_selected)):
    MAT[i][i]=ID5_selected[i]
    #print(ID5_selected[i])
#construct the matrix
mom_selected=[]
dau_check=[]
dau_tmp_rm=[]
mom_removed=[]
num_tr=[]
for i in range (len(ID5_removed)):
    if ID5_removed[i] in mom:
        for j in range (len(mom)):
            if mom[j]==ID5_removed[i]:
                mom_removed.append(mom[j])
                dau_tmp_rm.append(dau[j])
				
def recursion_elem(s_index,mom_ind):
	"""
	Input:
		s_index: a set of indexs of subsect of mom, distinct elements 
	Returns:
		a set of 
	"""

	# find tau(s)
	if len(mom_ind)==0:
		return
	print("###########################")
	corresponding_dau = [] 
	#corresponding_BR =[]
	for m_id in s_index: # e.g., s_index= (0, 4)
		corresponding_dau.append(dau[m_id]) # dau = [2004, 200]
	#	corresponding_BR.append(br[m_id])

	# daus(s) intersects sel 
	dau_in_sel_ind = [i for i in s_index if dau[i] in ID5_selected] # @TODO: find index of dau instead of its value!

	print("(mom,Dau) in sel:", [mom[i]  for i in dau_in_sel_ind ], [dau[i] for i in dau_in_sel_ind ] )
	for i in range (len(dau_in_sel_ind)):
         mom_selected.append(mom[mom_ind[0]])
         dau_check.append(dau[dau_in_sel_ind[i]])
		# need to adjust index of mom , 0 only for decay path 
		#print(mom[mom_ind[0]],dau[dau_in_sel_ind[i]])#,br[dau_in_sel_ind[i]])
	# dau(s) / sel 
	subs = [i for i in corresponding_dau if i not in ID5_selected]
	# subs not in mom_removed 
	subs_not_in_mom = [i for i in subs if i not in mom]
	if len(subs_not_in_mom)!=0:
		print("who are you???")
		print(subs_not_in_mom)
		return
	#print("Dau in sel not in mom", subs_not_in_mom)
        # subs intersects mom 
	rec_o = [i for i in subs if i in mom]
	rec_o_ind = convert_elem_to_index(rec_o)


	if len(rec_o_ind) == 0:
		return 0
	else:
		return recursion_elem(rec_o_ind,mom_ind) 


def convert_elem_to_index(elems):
	out = []
	for i in range(len(mom)):
		if mom[i] in elems:
			out.append(i)
	return out 

#def convert_dau_to_mom_index(dau):
#	out = []


for ii in range (len(ID5_selected)):
	tmp=[]
	if ID5_selected[ii] in mom:
		for kk in range (len (mom)):
			if mom[kk]==ID5_selected[ii]:
				tmp.append(kk)
	print(recursion_elem(tmp,tmp))
				
				
				
dau_check_real=[]
print(len(mom_selected),len(dau_check))
for i in range(len(dau_check)):
    if dau_check[i] in dau_check_real:
        continue
    else:
        dau_check_real.append(dau_check[i])
        #print(dau_check[i])
dau_check_real.sort()
#for i in range (
for t in range (len(dau_check_real)):
    for i in range (len(mom_selected)):
        if dau_check[i]==dau_check_real[t]:
            print(mom_selected[i],dau_check[i])
            for m in range (len(ID5_selected)):
                if ID5_selected[m]==dau_check[i]:
                    for n in range (len(ID5_selected)):
                        if ID5_selected[n]==mom_selected[i]:
                            #m=0
                            MAT[m][n]=mom_selected[i]







#stop
w=open(index_mat,'w')
#printing matrix
for i in range (len(ID5_selected)):
    for j in range (len(ID5_selected)):
        w.write('%12d'%MAT[i][j])
    w.write('\n')
w.close()
#

    #print(t)
