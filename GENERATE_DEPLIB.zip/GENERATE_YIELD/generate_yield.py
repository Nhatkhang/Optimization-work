import sys
input=sys.argv[1] ##file name
output=sys.argv[2] #out file name
#input='dep_endf71.nfy'
#output='testing'
w=open(output,'w')
f=open(input,'r')
num_line=sum(1 for line in f)
#print(num_line)
f.seek(0)
num_lines=[] #must have 31 elements
precusor=[]
e_point=[]
NFP=[]
FYI=[]
FYA=[]
NFP_ac=[]
arr_I=[]
arr_ac=[]
e_group=[]
c=0
test_line_I=[]
test_line_ac=[]
for i in range(num_line):
    line=f.readline()
    if (line.find('                                1        451         ')>=0):
        tmp=f.readline()
        tmp=tmp.split()
        #print(tmp[2])
        nu_line=int(tmp[2])
        num_lines.append(int(tmp[2]))
        f.readline()
        f.readline()
        f.readline()
        tmp=f.readline()
        tmp=tmp.split()
        #print(tmp)
        #stop
        num_e_group=int(tmp[2])
        nu=tmp[0].split('+')
        nu=int(round(float(nu[0])*10**(int(nu[1])+1)))
### iso state not provided for fertile nucldes
        if nu== 952420:
            nu=nu+1
        c=c+1
        #precusor.append(nu)
        #e_group.append(num_e_group)
        #print(nu,num_e_group)
        #this part is for independent yield
        if num_e_group !=0:
            for ii in range (num_e_group):
                precusor.append(nu)
                e_group.append(num_e_group)
                tmp=f.readline()
                tmp=tmp.split()
                e_point.append(tmp[0])
                t=divmod(int(tmp[4]),4)[0]
                NFP.append(t)
                tmp_line=divmod(int(tmp[4]),6)
                if tmp_line[1]>0:
                    lines=tmp_line[0]+1
                else:
                    lines=tmp_line[0]
                test_line_I.append(lines)
                for j in range(lines):
                    temp=f.readline()
                    temp=temp[0:66]
                    temp=temp.split()
                    for k in range(len(temp)):
                        arr_I.append(temp[k])
                   # print(hmm)
                #print(nu_line,lines)
        #### done all group then it moves to Accumulative yield
        f.readline()
        f.readline()
        #### this part is for accumulative yield
        if num_e_group !=0:
            for ii in range(num_e_group):
                tmp=f.readline()
                tmp=tmp.split()
                print(divmod(int(tmp[4]),4)[0])
                NFP_ac.append(divmod(int(tmp[4]),4)[0])
                tmp_line=divmod(int(tmp[4]),6)
                if tmp_line[1]>0:
                    lines=tmp_line[0]+1
                else:
                    lines=tmp_line[0]
                test_line_ac.append(lines)
                for j in range (lines):
                    temp=f.readline()
                    temp=temp[0:66]
                    temp=temp.split()
                    for k in range(len(temp)):
                        arr_ac.append(temp[k])
#### deleting the redundancy 

for i in range (len(NFP)):
    print(precusor[i],NFP[i],e_point[i],e_group[i])
t=[i for (i,j) in enumerate(e_point) if e_point[i]=='2.000000+6']
print(t)
####
print(len(arr_I),sum(NFP),sum(test_line_I))
#stop
print(NFP[t[0]],test_line_I[t[0]])
if len(t)!=0:
    sumdela_I=int(4*sum(NFP[0:t[0]]))
    sumdelb_I=int(sumdela_I+4*int(NFP[t[0]]))
    sumdela_ac=int(4*sum(NFP[0:t[0]]))
    sumdelb_ac=int(sumdela_ac+4*int(NFP[t[0]]))
    #print(sumdela,tmp[t[0]],sumdelb)
    del(arr_I[sumdela_I:sumdelb_I])
    del(arr_ac[sumdela_ac:sumdelb_ac])
    del(precusor[t[0]])
    del(NFP[t[0]])
    del(NFP_ac[t[0]])
    del(e_point[t[0]])
    del(e_group[t[0]])
    for i in range (len(NFP)):
        print(precusor[i],NFP[i],e_point[i],e_group[i])
        if e_group[i]==4:
            e_group[i]=3
print(sum(NFP),len(NFP))
print(len(arr_I))
print(sum(NFP_ac),len(NFP_ac))
print(len(arr_ac))
print('----------------------------------------Done reading------------------------------------')
##### independent yield####

temp=[]
check=[]
for i in range (sum(NFP)): 
    temp.append([])
    check.append([])
    for j in range(4):
        temp[i].append('0')
    for jj in range (2):
        check[i].append(0.0)
index=0
print('arr_I for independent, arr_ac for accumulative')
for i in range (sum(NFP)):
    for j in range (4):
        temp[i][j]=arr_ac[index]
        index=index+1
print(len(temp[0]))
### find the value 
for i in range (sum(NFP)):
    if(temp[i][0].find('+')>0 ):
        nuc=temp[i][0].split('+')
        nuc=int(round(float(nuc[0])*10**(int(nuc[1])+1)))
    if(temp[i][1].find('+')>0 ):
        iso=temp[i][1].split('+')
        iso=int(float(iso[0]))
    check[i][0]=int(iso+nuc)
    print(temp[i][2])
    #print(check[i][0])
    if(temp[i][2].find('+')>0 ):
        yi=temp[i][2].split('+')
        yi=float((float(yi[0])*10**(int(yi[1]))))
    elif (temp[i][2].find('-')>0 ):
        yi=temp[i][2].split('-')
        yi=float((float(yi[0])*10**((-1)*int(yi[1]))))
    #print(yi,temp[i][2])
    check[i][1]=100*yi #convert to percentage
### done loading value 
print('Creating the nuclide list')
NU_ID=[]
for i in range (sum(NFP)):
    if check[i][0] not in NU_ID:
        NU_ID.append(check[i][0])
print('Fission yield library contains: '+str(len(NU_ID))+' nuclides')
#### creating array
NU_ID.sort()
Arr=[]
for i in range (len(NU_ID)):
    Arr.append([])
    for j in range (int(c*3)+1):
        Arr[i].append(0.0)
for i in range (len(NU_ID)):
    Arr[i][0]=NU_ID[i]
## create the energy order
Erg_order=[]
tmp=[]
listy=[]
a=0
for i in range (len(NFP)):
    if e_point[i].find('+') >0:
        Erg=e_point[i].split('+')
        Erg=float(float(Erg[0])*10**(int(Erg[1])))
    elif e_point[i].find('-') >0:
        Erg=e_point[i].split('-')
        Erg=float(float(Erg[0])*10**((-1)*int(Erg[1])))
    tmp.append(round(Erg,3))
for i in range (len(tmp)):
    if (tmp[i]==min(tmp)):
        a=1
    elif (tmp[i]==max(tmp)):
        a=3
    else:
        a=2
    Erg_order.append(a)
for i in range (len(NFP)):
    print(precusor[i],e_group[i],NFP[i],tmp[i],Erg_order[i])
idx=0
count=0
for ll in range (len(NFP)):
    testnu=[]
    testy=[]
    tmp=[]
    for kk in range(len(NU_ID)):
        tmp.append(0.0)
    for k in range (NFP[ll]):
        testnu.append(check[idx][0])
        testy.append(check[idx][1])
        idx=idx+1
    #print(len(testnu))
    tt=[i for (i,j) in enumerate(NU_ID) if NU_ID[i] in testnu]
    #print(len(tt))
    for ii in range(len(tt)):
        tmp[tt[ii]]=testy[ii]
    if e_group[ll]==1:
        for o in range (3):
            for xx in range(len(tmp)):
                listy.append(tmp[xx])
                count=count+1
    elif e_group[ll]==2 and Erg_order[ll]==2:
        for o in range (2):
            for xx in range(len(tmp)):
                listy.append(tmp[xx])
                count=count+1
    else:
        for xx in range(len(tmp)):
            listy.append(tmp[xx])
            count=count+1

    print(precusor[ll],e_group[ll],Erg_order[ll])
print(idx,sum(NFP))
print(count)
print(len(listy))
print(c)
##### test
#done copying
index=0
for j in range (1,int(3*c)+1):
    for i in range (len((NU_ID))):
        Arr[i][j]=listy[index]
        index=index+1
print(index, len(listy))
## writing part
###
mn=[]
mom=[]
for i in range (len(precusor)):
    if precusor[i] not in mom:
        mom.append(precusor[i])
n=4
m=10
test=[]
for i in range (n):
    test.append([])
    for j in range(m):
        test[i].append(0.0)
cc=0
rr=0
for i in range (len(mom)):
    test[cc][rr]=mom[i]
    rr=rr+1
    if rr>9:
        rr=0
        cc=cc+1
for i in range(n):
    if(i==0):
        w.write(str(c)+'  ')
    else:
        w.write('    ')
    for j in range (m):
        if (test[i][j] !=0.0):
            w.write(str(test[i][j])+'   ')
    w.write('\n')
w.write('3   1 3.00e+06 20.00e+06'+'\n')
### Energy BC in ev
for i in range (len(NU_ID)):
    for j in range (int(3*c)+1):
        if j == 0 :
            w.write('%5d'%int(Arr[i][j])+'   ')
        else:
            w.write('%5e'%float(Arr[i][j])+'   ')
    w.write('\n')
w.close()
f.close()
        
print('########################################################################################')
print('The FY library is generated '+str(output))
print('Number of fertile/fissile nuclide: ' +str(c))
print('Number of FPs: '+str(len(NU_ID)))
print('Created by Khang')
