using python to generate fission library with the following comand without ""
python generate_yield.py "name of your ENDF-VI format FY data file " "your desired name of output library"