import os
import sys
inp=sys.argv[1]
f=open(inp,'r')
w=open('r_type','w')
ww=open('num_nu','w')
c=0
num_line=sum(1 for line in f)
f.seek(0)
r_type=[]
for i in range(num_line):
    line=f.readline()
    if line.find('0.000000+0 ')>=0 and line.find('1  099999')>=0:
        f.readline()
        tmp=f.readline()
        if tmp.find('8457')>=0:
            tmp=tmp.split()
            LIS=tmp[2]
            LISO=tmp[3]
            tmp=tmp[0].split('+')
            ID=float(tmp[0])*10**(1+int(tmp[1]))+int(LISO)
            #print(ID)
            c=c+1
            f.readline()
            f.readline()
            temp=f.readline()
            num_br=int(temp[65])
            #print(num_br)
            #stop
            if num_br !=0:
                for k in range (num_br):
                    temp=f.readline()
                    temp=temp.split()
                    if temp[0].find('+')>=0:
                        br=temp[0].split('+')
                        br=float(br[0])*10**(int(br[1]))
                    elif temp[0].find('-')>=0:
                        br=temp[0].split('-')
                        br=float(br[0])*10**((-1)*int(br[1]))
                    if temp[1].find('+')>=0:
                        flag=temp[1].split('+')
                        flag=float(flag[0])*10**((int(flag[1])))
                        #flag=float(flag[0])*10**((-1)*(int(flag[1])))
                        flag=flag*10**(-4)
                    elif temp[1].find('-')>=0:
                        flag=temp[1].split('-')
                        flag=float(flag[0])*10**((-1)*(int(flag[1])))
                        flag=flag*10**(-4)
                        #print(flag)
                    #print (temp[3],temp[4])
                    type=br+flag
                    if (type in r_type):
                        #print(type)
                        aaa=111
                    else:
                        r_type.append(type)
                    #print (type)
                    #stop
                    #w.write('%5f'%type+'\n')
f.close
r_type.sort()
#print(r_type)
for i in range (len(r_type)):
    w.write('%.5f'%r_type[i]+'\n')
w.close()
ww.write('%5d'%int(c))
ww.close()
