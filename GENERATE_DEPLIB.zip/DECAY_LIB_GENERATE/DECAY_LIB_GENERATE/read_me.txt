using python to generate decay library with the following comand without ""
python run.py "name of your ENDF-VI format decay data file " "your desired name of output library"