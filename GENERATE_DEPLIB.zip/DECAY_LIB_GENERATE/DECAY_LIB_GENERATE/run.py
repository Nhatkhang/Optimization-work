import os 
import sys
input=sys.argv[1] #name of ENDF file 
output=sys.argv[2] ## name of out put lib
os.system('python find_r_type.py '+str(input))
os.system('python generate_decay_lib.py '+str(input)+' r_type '+'num_nu '+str(output))
os.system('rm -f r_type')
os.system('rm -f num_nu')
