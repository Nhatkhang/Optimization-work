import sys
input1=sys.argv[1] # this is name of the ENDF file
input2=sys.argv [2] # name of r_type
input3=sys.argv [3] #num_nu 
output=sys.argv[4]
f=open(input3,'r')
num_ID=int(f.readline())-1
f=open(input2,'r')
num_line=sum(1 for line in f)              
f.seek(0)                                  
arr=[]                                     
for i in range(num_line):                  
    arr.append(f.readline().split('\n')[0])
f.close()                                  

f=open(input1,'r')
w=open(output,'w')
w.write('ID     ID5     MASS         FRACTION     HALFLIFE(S)   ')
for i in range (num_line):
    w.write('%12.5e'%float(arr[i]))
w.write('\n')
num_line=sum(1 for line in f)
f.seek(0)
nu_ID=[]
Mass=[]
Fraction=[]
for i in range(num_ID):
    Fraction.append('0.0')
T=[]
BR=[]
nu_ID5=[]
RTYP=arr
size=len(RTYP)
for x in range(num_ID*size):
    BR.append('0.0')
index=0
a=0
for i in range(num_line):
	line=f.readline()
	if line.find('0.000000+0 ')>=0 and line.find('  099999')>=0:
		f.readline()
		tmp=f.readline()
		if tmp.find('8457')>=0:
			tmp=tmp.split()
			LIS=tmp[2]
			LISO=tmp[3]
            #print(LISO)
            #print(LIS)
			m=tmp[1]
			if m.find('-')>=0:
				mass=float(m.split('-')[0])*10**((-1)*(float(m.split('-')[1])))
			elif  m.find('+')>=0:
				mass=float(m.split('+')[0])*10**(float(m.split('+')[1]))
			tmp=tmp[0].split('+')
			ID=float(tmp[0])*10**(1+int(tmp[1]))+int(LISO)
			#print(ID)
			ID5=float(tmp[0])*10**(int(tmp[1]))
			if (int(LISO)==0):
				ID5=ID5
			elif (int(LISO)==1):
				ID5=ID5+400
			elif (int(LISO)==2):
				ID5=ID5+500
			elif (int(LISO)==3):
				ID5=ID5+600
			if round(ID)> 1000:
				temp=f.readline()
				temp=temp.split()
				if temp[0].find('+')>=0:
					halflife=float(temp[0].split('+')[0])*10**(float(temp[0].split('+')[1]))
				elif temp[0].find('-')>=0:
					halflife=float(temp[0].split('-')[0])*10**((-1)*(float(temp[0].split('-')[1])))
				nu_ID.append(round(ID))
				nu_ID5.append(round(ID5))
				T.append(halflife)
				Mass.append(mass)
				f.readline()
				temp=f.readline()
				num_br=int(temp[65])
				if num_br != 0 :
					b=0
					for k in range(num_br):
						tmp=f.readline()
						tmp=tmp.split()
						rtyp_check=tmp[0].split('+')
						rtyp=float(rtyp_check[0])*10**(int(rtyp_check[1]))
						if tmp[1].find('+')>=0:
							flag=tmp[1].split('+')
							flag=float(flag[0])*10**((int(flag[1])))
							flag=flag*10**(-4)
						elif temp[1].find('-')>=0:
							flag=temp[1].split('-')
							flag=float(flag[0])*10**((-1)*(int(flag[1])))
							flag=flag*10**(-4)
						rtyp=rtyp+flag
						#print(rtyp)
						for i in range (size):
							if rtyp == float(RTYP[i]):
								index=index+i-b
								a=i
								b=i
                                #print(a)
								#print(tmp[4])
								#stop
						if tmp[4].find('+')>=0:
							tmp=tmp[4].split('+')
							br=float(tmp[0])*10**(int(tmp[1]))
							BR[index]=br
							#print(k,num_br,rtyp,br,index)
                            #index=index+1
						elif tmp[4].find('-')>=0:
							tmp=tmp[4].split('-')
							br=float(tmp[0])*10**((-1)*int(tmp[1]))
							BR[index]=br
							#print(k,num_br,rtyp,br,index)
					index=index+(size-a)
				else:
					index=index+size
				#print(num_br)
				#stop
                #if index > num_ID*18:
                #    print(index)
                #    stop
#print(index)
#print(len(Mass))
f.seek(0)
for i in range(num_line):
	line=f.readline()
    #print(line)
	if line.find('Abundance: ')>=0:
		abc=line.split('%')
		frac=float(abc[0].split()[1])
		f.readline()
		f.readline()
		f.readline()
		f.readline()
		f.readline()
		tmp=f.readline()
		tmp=tmp.split()
		tmp=tmp[0].split('+')
		ID_temp=float(tmp[0])*10**(1+int(tmp[1]))
		for i in range (num_ID):
			if round(ID_temp)==nu_ID[i]:
				Fraction[i]=frac
                #print(Fraction[i])                

a=0
RE=[]
for x in range (num_ID):
	RE.append([])
	for y in range (size+5):
		RE[x].append([])
for i in range (num_ID):
	RE[i][0]='%d'%nu_ID[i]
	RE[i][1]='%d'%nu_ID5[i]
	RE[i][4]='%12.5e'%T[i]
	RE[i][2]='%12.5e'%Mass[i]
	RE[i][3]='%12.5e'%float(Fraction[i])
	for j in range (5,size+5):
		RE[i][j]='%12.5e'%float(BR[a])
		a=a+1
print(a)
print(len(BR))
q=0
for j in range (num_ID):
    for i in range (1,num_ID):
        if int(RE[i][1])<int(RE[i-1][1]):
            print(RE[i][1],RE[i-1][1])
            #q=q+1
            tmp=RE[i][:]
            RE[i][:]=RE[i-1][:]
            RE[i-1][:]=tmp
            print(RE[i][1],RE[i-1][1])
            #if i == 137:
            #    stop
   # print(q)
   # stop

        #stop
        #RE[i][:]=RE[i-1][:]
#stop

for i in range (num_ID):
	for j in range (size+5):
		w.write(RE[i][j]+' ')
	w.write('\n')
    #print(BR[i:i+5])
print("????")
for i in range (num_ID):
    print(nu_ID5[i])

f.close
w.close



print('#########')
#print('Cf252 is not included because of its special format')
print('Done geneate decay lib: '+str(output))
print('number of decay mode : '+str(len(RTYP)))
print('number o nuclide in lib: '+str(num_ID))
print('#########')
print('created by Khang')
